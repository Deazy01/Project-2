
#include "FriendGroups.h"
#include "HashMap.h"
#include "UnionFindImpl.h"
struct CFriendGroups::SImplementation
{
    CHashMap<TName, std::size_t> Names;
    CUnionFindImpl Groups;
    std::vector<TName> People;
    std::size_t GetOrAdd(const TName &name)
    {
        std::size_t id;
        if (Names.Find(name, id))
            return id;
        id = Groups.AddElement();
        Names.Add(name, id);
        People.push_back(name);
        return id;
    }
};
CFriendGroups::CFriendGroups() : DImplementation(std::make_unique<SImplementation>()) {}
CFriendGroups::~CFriendGroups() = default;
bool CFriendGroups::SameFriendGroup(const TConnection &connection) noexcept
{
    std::size_t a, b;
    return DImplementation->Names.Find(std::get<0>(connection), a) && DImplementation->Names.Find(std::get<1>(connection), b) && DImplementation->Groups.Connected(a, b);
}
void CFriendGroups::AddFriendship(const TConnection &connection) noexcept
{
    auto a = DImplementation->GetOrAdd(std::get<0>(connection));
    auto b = DImplementation->GetOrAdd(std::get<1>(connection));
    DImplementation->Groups.Union(a, b);
}
std::vector<CFriendGroups::TConnection> CFriendGroups::FriendshipsForSingleGroup() noexcept
{
    std::vector<TConnection> result;
    auto &impl = *DImplementation;
    if (impl.Groups.GroupCount() < 2)
        return result;
    result.reserve(impl.Groups.GroupCount() - 1);
    std::vector<bool> seen(impl.Groups.Size(), false);
    std::size_t previous = 0;
    bool havePrevious = false;
    for (std::size_t id = 0; id < impl.People.size(); ++id)
    {
        auto root = impl.Groups.Find(id);
        if (seen[root])
            continue;
        seen[root] = true;
        // k groups require k-1 edges; a chain gives degree at most two.
        if (havePrevious)
            result.emplace_back(impl.People[previous], impl.People[id]);
        previous = id;
        havePrevious = true;
    }
    return result;
}
