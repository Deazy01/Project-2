
#include "HashMap.h"
#include <string>
template class CHashMap<int, int>;
template class CHashMap<std::string, std::size_t>;
