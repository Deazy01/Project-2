from pathlib import Path
import subprocess,re,json,statistics
p=Path(__file__).resolve().parents[1]
# AI-assisted. Run after make completes successfully.
rows=[]
for name in ['friends1','friendssm','friendsmed','friendslg']:
 trials=[]
 for _ in range(5):
  r=subprocess.run([str(p/'bin/makefriends'),'-f',str(p/f'data/{name}.csv'),'-v'],text=True,capture_output=True,check=True)
  found=re.search(r'Processed ([\d,]+) people with ([\d,]+) connections in ([\d,]+)ns',r.stderr)
  n,m,t=[int(x.replace(',','')) for x in found.groups()]
  trials.append(t)
 rows.append(dict(file=name+'.csv',people=n,connections=m,additional_connections=len(r.stdout.splitlines()),times_ns=trials,median_ns=int(statistics.median(trials))))
(p/'evidence/benchmarks.json').write_text(json.dumps(rows,indent=2)+'\n')
for row in rows: print(row)
