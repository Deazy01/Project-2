
#ifndef HASH_MAP_H
#define HASH_MAP_H
#include "Map.h"
#include <vector>
#include <list>
#include <tuple>
#include <functional>
#include <utility>
// Separate chaining. K must support std::hash and equality.
// Iteration order is unspecified; callbacks must not mutate this map.
template <class K, class V>
class CHashMap final : public CMap<K, V>
{
    using TEntry = std::tuple<K, V>;
    std::vector<std::list<TEntry>> DBuckets{16};
    std::size_t DSize = 0;
    std::size_t Bucket(const K &key) const
    {
        return std::hash<K>{}(key) % DBuckets.size();
    }
    void Grow()
    {
        std::vector<std::list<TEntry>> larger(DBuckets.size() * 2);
        for (auto &bucket : DBuckets)
        {
            while (!bucket.empty())
            {
                auto entry = bucket.begin();
                auto index = std::hash<K>{}(std::get<0>(*entry)) % larger.size();
                larger[index].splice(larger[index].end(), bucket, entry);
            }
        }
        DBuckets.swap(larger);
    }

public:
    std::size_t Size() const override { return DSize; }
    bool Add(const K &key, V val) override
    {
        for (const auto &entry : DBuckets[Bucket(key)])
            if (std::get<0>(entry) == key)
                return false;
        if (DSize >= DBuckets.size())
            Grow();
        DBuckets[Bucket(key)].emplace_back(key, std::move(val));
        ++DSize;
        return true;
    }
    bool Remove(const K &key) override
    {
        auto &bucket = DBuckets[Bucket(key)];
        for (auto it = bucket.begin(); it != bucket.end(); ++it)
        {
            if (std::get<0>(*it) == key)
            {
                bucket.erase(it);
                --DSize;
                return true;
            }
        }
        return false;
    }
    bool Find(const K &key, V &val) const override
    {
        for (const auto &entry : DBuckets[Bucket(key)])
        {
            if (std::get<0>(entry) == key)
            {
                val = std::get<1>(entry);
                return true;
            }
        }
        return false;
    }
    void ForEach(typename CMap<K, V>::TEntityFunction fun) override
    {
        for (const auto &bucket : DBuckets)
            for (const auto &entry : bucket)
                fun(std::get<0>(entry), std::get<1>(entry));
    }
};
#endif
