#ifndef UNION_FIND_IMPL_H
#define UNION_FIND_IMPL_H

#include "UnionFind.h"
#include <vector>

class CUnionFindImpl : public CUnionFind {
    private:
        std::vector<TElementID> DParent;
        std::vector<std::size_t> DWeight;
        std::size_t DGroups = 0;
    public:
        std::size_t Size() const override { return DParent.size(); }
        std::size_t GroupCount() const override { return DGroups; }
        TElementID AddElement() override {
            TElementID id = DParent.size();
            DParent.push_back(id);
            DWeight.push_back(1);
            ++DGroups;
            return id;
        }
        TGroupID Find(TElementID a) const override {
            if (a >= Size()) return InvalidGroupID;
            while (a != DParent[a]) {
                a = DParent[a];
            }
            return a;
        }
        bool Union(TElementID a, TElementID b) override {
            TGroupID groupA = Find(a);
            TGroupID groupB = Find(b);
            if (groupA == InvalidGroupID || groupB == InvalidGroupID || groupA == groupB) return false;
            if (DWeight[groupA] < DWeight[groupB]) {
                TGroupID temp = groupA;
                groupA = groupB;
                groupB = temp;
            }
            DParent[groupB] = groupA;
            DWeight[groupA] += DWeight[groupB];
            --DGroups;
            return true;
        }
        bool Connected(TElementID a, TElementID b) override {
            TGroupID groupA = Find(a);
            TGroupID groupB = Find(b);
            return groupA != InvalidGroupID && groupA == groupB;
        }
};

#endif 