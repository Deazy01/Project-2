
#ifndef WEIGHTED_UNION_FIND_H
#define WEIGHTED_UNION_FIND_H
#include "UnionFind.h"
#include <vector>
class CWeightedUnionFind final : public CUnionFind {
    mutable std::vector<TElementID> DParent;
    std::vector<std::size_t> DWeight;
    std::size_t DGroups = 0;
public:
    std::size_t Size() const override { return DParent.size(); }
    std::size_t GroupCount() const override { return DGroups; }
    TElementID AddElement() override {
        auto id = Size(); DParent.push_back(id); DWeight.push_back(1);
        ++DGroups; return id;
    }
    TGroupID Find(TElementID a) const override {
        if (a >= Size()) return InvalidGroupID;
        // Path halving changes tree shape without changing group membership.
        while (a != DParent[a]) {
            DParent[a] = DParent[DParent[a]];
            a = DParent[a];
        }
        return a;
    }
    bool Union(TElementID a, TElementID b) override {
        a = Find(a); b = Find(b);
        if (a == InvalidGroupID || b == InvalidGroupID || a == b) return false;
        if (DWeight[a] < DWeight[b]) { auto tmp = a; a = b; b = tmp; }
        DParent[b] = a; DWeight[a] += DWeight[b]; --DGroups; return true;
    }
    bool Connected(TElementID a, TElementID b) override {
        auto root = Find(a);
        return root != InvalidGroupID && root == Find(b);
    }
};
#endif
