# Make Friends Analysis

## Data

Results below were collected inside the Docker container on October 25, 2026.
Student timings are single normal runs from the completed `make` output,
not averages or medians.

|            | CPU EPS  |
|------------|---------:|
| Instructor | 5,671.61 |
| Student    | 263.37   |

|        | Scaling     |
|--------|------------:|
| I-to-S | 21.53476098 |

The scaling factor is calculated as:

```text
I-to-S = Instructor EPS / Student EPS
       = 5671.61 / 263.37
       = 21.53476098

Scaled instructor time = Original instructor time × I-to-S
Maximum allowed time = Scaled instructor time × 1.30
```

The instructor times in the following table are scaled to the student's
CPU benchmark result and rounded to the nearest nanosecond.

| File           | I People | I Con   | I Add Con | I Time (ns, scaled) | S Con   | S Add Con | S Time (ns) |
|----------------|---------:|--------:|----------:|--------------------:|--------:|----------:|------------:|
| friends1.csv   | 10       | 19      | 0         | 1,461,672           | 19      | 0         | 84,461     |
| friendssm.csv  | 10       | 12      | 1         | 872,158             | 12      | 1         | 95,745      |
| friendsmed.csv | 1,000    | 3,927   | 4         | 223,059,746         | 3,926   | 4         | 4,744,330   |
| friendslg.csv  | 100,000  | 416,102 | 29        | 19,697,606,297      | 416,102 | 29        | 744,437,849 |

Note: The supplied medium dataset contains 3,926 connections, while the
instructor's table lists 3,927. The supplied dataset was not modified.

### Performance Comparison

The requirement is that student runtime must be no more than 30% slower
than the scaled instructor runtime.

| File           | Original Instructor Time (ns) | Maximum Allowed Time (ns) | Student Time (ns) | Result |
|----------------|-----------------------------:|-------------------------:|-----------------:|--------|
| friends1.csv   | 67,875                       | 1,900,173                | 84,461           | Pass   |
| friendssm.csv  | 40,500                       | 1,133,805                | 95,745           | Pass   |
| friendsmed.csv | 10,358,125                   | 289,977,670              | 4,744,330        | Pass   |
| friendslg.csv  | 914,688,875                  | 25,606,888,186           | 744,437,849      | Pass   |

All four observed runtimes meet the performance requirement under the
specified scaling method.

CPU scaling is approximate and does not fully account for differences in
memory performance, caches, compiler versions, virtualization, or background
activity. Repeated timing runs would improve confidence in these results.

### Measurement Method

The following commands were executed inside the Docker container:

```sh
make clean
make
echo $?
```

The final exit status was `0`.

The compiler used `-O0 --std=c++20`.

The CPU benchmark command was:

```sh
sysbench cpu --cpu-max-prime=20000 --threads=1 run
```

It reported 263.37 events per second.

The normal execution times were taken from the driver's internal timer.
This timer includes construction of CFriendGroups, insertion of input
friendships, and generation of suggested connections. It excludes input
loading, subsequent solution application and validation, and printed output.

The medium-file runtime under Valgrind was 277,744,446 ns. This value was
excluded from the performance comparison because Valgrind adds overhead.

## Analysis

### What seems to be the growth rate for your Friend Groups structure in terms of number of people?

Let n be the number of people and m be the number of input friendships.

With average-case hashing and bounded name lengths, expected processing
time is O(n + m log(n)). The custom hash map provides expected
amortized O(1) operations, and Union-Find uses union by size, not using path compression, making O(log n) to be the worst case time complexity.

When the number of friendships grows roughly in proportion to the number
of people, expected total runtime is O(n log(n)), close to linear in the number of people.

Hashing costs also depend on name lengths. Retained data-structure space
is O(n), excluding name lengths and storage used by the supplied driver.

### Does it appear to grow faster or slower than expected?

From the medium to large dataset, the number of people increases by
100 times and the number of input connections increases by approximately
106 times.

The observed runtime increases by approximately 156.9 times:

```text
744,437,849 / 4,744,330 ≈ 156.9
```

Runtime therefore grows slightly faster than the increase in input
connections, but these observations are broadly consistent with the
expected near-linear growth.

The results are single-run measurements from only four datasets, so they
are not sufficient to establish an empirical asymptotic growth rate.

### If your implementation is deviating, why do you believe your implementation is deviating from what might be expected?

Larger datasets require larger hash tables and Union-Find vectors, which
can cause more cache misses. Strings and list nodes also require
allocations and pointer traversal.

Hash-table resizing requires existing entries to be rehashed. These
operations can increase the constant cost per input connection even when
the expected overall complexity remains nearly linear.

Docker scheduling and other system activity can also affect runtime.
These are plausible explanations; a profiler was not used to isolate
the contribution of each factor.

### What do you believe is the dominant structure/algorithm in your implementation?

The expected dominant work is hashing and looking up the two names for
each input friendship.

The custom hash map uses separate chaining and grows to keep its load
factor at most one after insertion. Union-Find merges numeric IDs using
union by size with no path compression.

Friendship suggestion generation scans the people, identifies one
representative per group, and connects consecutive representatives in a
chain. This assessment is based on the code and operation counts rather
than profiling.

For k separate groups, at least k - 1 new friendships are necessary because
one new friendship can reduce the number of groups by at most one.

The chain produces exactly k - 1 friendships. Each representative appears
at most twice, satisfying the per-person limit.

## Testing and Verification

| Check                         | Result                         |
|-------------------------------|--------------------------------|
| Map tests                     | 23 passed                      |
| Union-Find tests              | 20 passed                      |
| FriendGroups tests            | 5 passed                       |
| Total tests                   | 48 passed                      |
| Implementation line coverage  | 100.0% — 126/126 lines            |
| Function coverage             | 80.9% — 38/47 functions         |
| HTML coverage report          | Generated successfully         |
| Valgrind errors               | 0                              |
| Definitely lost memory        | 0 bytes                        |
| Indirectly lost memory        | 0 bytes                        |
| Possibly lost memory          | 0 bytes                        |
| Still-reachable memory        | 1,375 bytes in 15 blocks        |
| Normal dataset runs           | All four completed successfully |
| Final make exit status        | 0                              |

The initial coverage result included library and test code. After removing
`/usr/*` and `*/tests/src/*`, implementation line coverage was 100.0%.

Function coverage was 80.9%. Full line coverage does not mean every
function variant or possible behavior was tested.

The still-reachable memory reported by Valgrind traces to locale and
iostream allocations in the supplied driver/runtime. It is not classified
as lost memory and does not fail the specified definite/indirect leak check.

The terminal output identifies GCC/gcov 15.2.0 and Valgrind 3.25.1.
Coverage generation completed despite the inconsistent-data warnings
handled by the configured ignore settings.

The HTML coverage report is located at:

```text
tests/htmlcov/index.html
```

