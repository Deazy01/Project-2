#include "Map.h"
#include "HashMap.h"
#include <memory>


template <typename T>
struct SMapFactory;

template<typename K, typename V>
struct SMapFactory<CHashMap<K,V> > {
    static std::unique_ptr<CMap<K,V>> Create(){
        return std::make_unique<CHashMap<K,V>>();
    }
};
