
#include <gtest/gtest.h>
#include "FriendGroups.h"
TEST(FriendGroupsExtra, QueriesDoNotInsertAndEmptySolution) {
    CFriendGroups groups;
    EXPECT_FALSE(groups.SameFriendGroup({"unknown","unknown"}));
    EXPECT_TRUE(groups.FriendshipsForSingleGroup().empty());
    groups.AddFriendship({"a","b"}); groups.AddFriendship({"b","c"});
    EXPECT_TRUE(groups.SameFriendGroup({"c","a"}));
    EXPECT_FALSE(groups.SameFriendGroup({"a","unknown"}));
    EXPECT_TRUE(groups.FriendshipsForSingleGroup().empty());
}
TEST(FriendGroupsExtra, MinimumChainAndUsageLimit) {
    CFriendGroups groups;
    for (int i=0;i<20;++i) {
        auto name=std::to_string(i); groups.AddFriendship({name,name});
    }
    auto result=groups.FriendshipsForSingleGroup();
    ASSERT_EQ(result.size(),19u);
    EXPECT_EQ(groups.FriendshipsForSingleGroup(),result);
    std::vector<int> uses(20,0);
    for (const auto &edge:result) {
        EXPECT_FALSE(groups.SameFriendGroup(edge));
        ++uses[std::stoi(std::get<0>(edge))]; ++uses[std::stoi(std::get<1>(edge))];
        groups.AddFriendship(edge);
    }
    for (int used:uses) { EXPECT_GE(used,1); EXPECT_LE(used,2); }
    EXPECT_TRUE(groups.FriendshipsForSingleGroup().empty());
    for (int i=0;i<20;++i) EXPECT_TRUE(groups.SameFriendGroup({"0",std::to_string(i)}));
}
TEST(FriendGroupsExtra, DuplicateSymmetricAndEmptyNames) {
    CFriendGroups groups;
    groups.AddFriendship({"","b"}); groups.AddFriendship({"b",""});
    groups.AddFriendship({"x","y"}); groups.AddFriendship({"y","z"});
    EXPECT_TRUE(groups.SameFriendGroup({"","b"}));
    EXPECT_TRUE(groups.SameFriendGroup({"z","x"}));
    auto result=groups.FriendshipsForSingleGroup(); ASSERT_EQ(result.size(),1u);
    EXPECT_FALSE(groups.SameFriendGroup(result.front()));
    groups.AddFriendship(result.front()); EXPECT_TRUE(groups.FriendshipsForSingleGroup().empty());
}
