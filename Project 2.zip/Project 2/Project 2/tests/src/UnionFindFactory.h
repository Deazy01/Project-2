#include "UnionFind.h"
#include "UnionFindImpl.h"
#include <memory>


template <typename T>
struct SUnionFindFactory;

template<>
struct SUnionFindFactory<CUnionFindImpl>{
    static std::unique_ptr<CUnionFind> Create(){
        return std::make_unique<CUnionFindImpl>();
    }
};
