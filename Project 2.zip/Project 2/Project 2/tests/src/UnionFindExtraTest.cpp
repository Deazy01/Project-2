
#include <gtest/gtest.h>
#include "WeightedUnionFind.h"
TEST(UnionFindExtra, InvalidIDsNeverConnect)
{
    CWeightedUnionFind uf;
    uf.AddElement();
    EXPECT_FALSE(uf.Connected(9, 9));
    EXPECT_FALSE(uf.Connected(0, 9));
    EXPECT_FALSE(uf.Union(9, 0));
    EXPECT_FALSE(uf.Union(0, 9));
    EXPECT_EQ(uf.Find(CUnionFind::InvalidGroupID), CUnionFind::InvalidGroupID);
    EXPECT_EQ(uf.GroupCount(), 1u);
}
TEST(UnionFindExtra, BalancedMergesAndConstFind)
{
    CWeightedUnionFind uf;
    for (int i = 0; i < 1024; ++i)
        uf.AddElement();
    for (int width = 1; width < 1024; width *= 2)
        for (int i = 0; i < 1024; i += width * 2)
            ASSERT_TRUE(uf.Union(i, i + width));
    const auto &view = uf;
    for (int i = 0; i < 1024; ++i)
        EXPECT_EQ(view.Find(i), view.Find(0));
    EXPECT_EQ(uf.GroupCount(), 1u);
    EXPECT_FALSE(uf.Union(17, 500));
    EXPECT_EQ(uf.AddElement(), 1024u);
    EXPECT_EQ(uf.GroupCount(), 2u);
}
