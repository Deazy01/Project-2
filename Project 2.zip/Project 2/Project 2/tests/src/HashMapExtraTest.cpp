
#include <gtest/gtest.h>
#include "HashMap.h"
TEST(HashMapExtra, CollisionsAndRemovalPreserveNeighbors)
{
    CHashMap<int, int> map;
    for (int k : {0, 16, 32, 48})
        ASSERT_TRUE(map.Add(k, k + 1));
    ASSERT_TRUE(map.Remove(32));
    int value = -1;
    EXPECT_FALSE(map.Find(32, value));
    EXPECT_EQ(value, -1);
    for (int k : {0, 16, 48})
    {
        ASSERT_TRUE(map.Find(k, value));
        EXPECT_EQ(value, k + 1);
    }
    EXPECT_TRUE(map.Remove(0));
    EXPECT_TRUE(map.Remove(48));
    EXPECT_TRUE(map.Remove(16));
    EXPECT_EQ(map.Size(), 0u);
}
TEST(HashMapExtra, RehashPreservesAllValuesAndVisitsOnce)
{
    CHashMap<int, int> map;
    for (int i = 0; i < 4096; ++i)
        ASSERT_TRUE(map.Add(i, i * 7));
    std::vector<int> seen(4096, 0);
    map.ForEach([&](const int &k, const int &v)
                { ASSERT_GE(k,0); ASSERT_LT(k,4096); ++seen[k]; EXPECT_EQ(v,k*7); });
    for (int i = 0; i < 4096; ++i)
    {
        int value;
        ASSERT_TRUE(map.Find(i, value));
        EXPECT_EQ(value, i * 7);
        EXPECT_EQ(seen[i], 1);
    }
    EXPECT_FALSE(map.Add(2048, -1));
}
TEST(HashMapExtra, EmptyIterationAndStringKeys)
{
    CHashMap<std::string, int> map;
    int calls = 0;
    map.ForEach([&](const auto &, const auto &)
                { ++calls; });
    EXPECT_EQ(calls, 0);
    ASSERT_TRUE(map.Add("", 4));
    ASSERT_TRUE(map.Add("long name", 9));
    int value;
    ASSERT_TRUE(map.Find("", value));
    EXPECT_EQ(value, 4);
    EXPECT_TRUE(map.Remove(""));
    EXPECT_FALSE(map.Remove("missing"));
}
