# Project 2: Friend Groups

Student 1: TODO — enter actual partner name and student ID.
Student 2: Zhiyu Chen 923177764

## Project status
Implementation includes a custom chained hash map, two Union-Find implementations, and a minimal friendship-chain generator. See ANALYSIS.md and evidence/
for validation results. 
## Build and run
Open this directory in VS Code and select **Reopen in Container** using the
provided `.devcontainer` configuration. From the project root:

```sh
make                 # tests, HTML coverage, Valgrind, then all four data files
make test            # GoogleTest suites only
make coverage        # tests and tests/htmlcov/index.html
make memcheck        # medium data under Valgrind; fails on memory errors/leaks
make run             # successful Valgrind check, then all data files
make bin/makefriends # compile the normal, uninstrumented driver
./bin/makefriends -f data/friendsmed.csv -v
make clean
```

The compiler uses `-O0 --std=c++20`. Coverage objects and normal objects are kept
separate so instrumentation does not distort measured driver runtimes. Required
tools: g++, make, GoogleTest, lcov/genhtml, Valgrind, sysbench, and git. The supplied
Dockerfile installs them. `tests/htmlconv` is created to match the specification's
spelling; HTML output goes into `tests/htmlcov`.

## Design and behavior
- `CHashMap<K,V>` uses a vector of list buckets holding tuples. It doubles its
  bucket count when insertion would exceed load factor one. Duplicate Add leaves
  the original value intact. Missing Find leaves its output argument unchanged.
  Keys require equality and `std::hash<K>`; callbacks must not modify the map.
- `CWeightedUnionFind` stores parent and component-size vectors. Union attaches
  the smaller tree to the larger tree; Find halves paths. Invalid IDs return the
  invalid sentinel or false. Find is logically const but compresses parent paths;
  instances are not intended for concurrent access.
- `CUnionFindImpl` is another union find implementation. This one uses vectors to
  store the sizes and parent IDs. The Find function locates the group ID and not using
  path compression. The Union function union groups by size, merge small groups into
  larger groups.
- `CFriendGroups` maps names to numeric IDs and maintains a name vector. Unknown
  query names are not inserted. A self-friendship registers one person. Repeated
  and reversed friendships are harmless. Suggestions do not change the groups.
- To join k components, select one person per component and connect consecutive
  representatives. This returns k−1 edges, which is minimal because an edge can
  reduce the number of components by at most one. A chain has degree at most two,
  so each name is used at most twice. Zero or one component needs no new edge.
- `CMap` has an added virtual destructor: the supplied factory owns implementations
  through `unique_ptr<CMap<K,V>>`, requiring safe polymorphic destruction.

Expected hash operations are amortized O(1), excluding string hashing costs;
worst-case collisions can make them O(n). Union-Find using union by size has 
worst case O(log(n)) operations. Suggestions take O(n log(n)) time and O(n)
temporary space. Overall processing is expected O(n+m log(n)) time and O(n) 
retained space, excluding name lengths and the driver's input/output storage.

## Known limitations
The required `noexcept` FriendGroups interface means allocation failure terminates
execution. No thread safety is promised. 
The provided driver's own STL containers are unchanged; the new implementation
uses only string, vector, list, and tuple containers. Smart pointers and hash
functions are not STL containers.

## Code references
- Instructor-provided `proj2.tgz`: interfaces, tests, driver, datasets, Docker
  configuration, baseline timings, and documentation templates.
- User-supplied project specification in this conversation.
- OpenAI ChatGPT assistance described below. External implementation source
  was also searched to develop this solution.

## Generative AI Use

### Tool and Purpose
I used ChatGPT as a programming assistant for implementation,
debugging, testing, and documentation, following the course policy
authorizing properly documented programming prompts.

### Assistance Received
I provided the project specification and starter files to ChatGPT.
It helped explain algorithms,interpreted test
output, and assisted with the runtime analysis.


### My Contributions
## My Contributions-student 1

Apart from the Union-Find component handled by my partner, my
responsibilities covered:

- The Map component and its integration with FriendGroups.
- FriendGroups functionality and minimum friendship generation.
- The Makefile and build workflow.
- Additional Map and FriendGroups tests.
- Docker setup and execution of the full test pipeline.
- Code coverage and Valgrind verification.
- Dataset runtime measurements and CPU benchmarking.
- README and ANALYSIS documentation.


### My Partner's Contributions- student 2
- writing the CUnionFindImpl
- implemented Find and Union functions using union by size, not using path compression
- update CFriendGroups and Union-Find teststo use CUnionFindImpl instead
- run tests to make sure the new implementation worked
- checked new test coverage and Valgrind results
- update ANALYSIS and README

### Verification
I ran the implementation inside the Docker container. All 48 tests
passed, implementation line coverage reached 100%, and Valgrind
reported zero errors and zero lost bytes. All four datasets
completed successfully.

These results apply to the tested version. I will repeat the checks after integrating any changes.

### Prompt and Response Records
The detailed prompts, relevant AI responses, and resulting changes
are documented below.

### Prompt and Response Records

#### Prompt 1
I supplied the Project 2 specification and starter archive and asked:
“Explain the core concepts and tell me about main steps.”

#### Response 1
ChatGPT proposed and generated all core concepts and guided about a chained hash map, weighted
Union-Find with path halving, a FriendGroups implementation,
a Makefile, and additional GoogleTests.

#### Prompt 2
I supplied the build output and asked ChatGPT to check it.

#### Response 2
ChatGPT reviewed the output and identified 48 passing tests,
100% implementation line coverage, and zero Valgrind errors.

#### Resulting Changes
The verification results were recorded in the documentation.

#### Prompt 3
I supplied my sysbench output and requested what to  update in ANALYSIS.md.

#### Response 3
ChatGPT calculated the CPU scaling factor, compared the measured
runtimes with the instructor's limits, and drafted the analysis.

#### Resulting Changes
I updated ANALYSIS.md with the measurements and calculations.
#### Prompt 4
I sent the new test result and original analysis data to Chat GPT, asking it to check if there's any problems, and where I need to edit for the analysis part.

#### Response 4
ChatGPT analysis the test output for me and point out parts I need to update.

#### Resulting Changes
I updated the parts mentioned by GPT in ANALYSIS.md